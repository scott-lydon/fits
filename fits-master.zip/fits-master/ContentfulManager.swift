//
//  ContentfulManager.swift
//  fits
//
//  Created by Vibes on 3/22/17.
//  Copyright © 2017 PZRT. All rights reserved.
//

import Foundation
import Contentful
import Interstellar


